#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 13:32:04 2023

@author: luyin
"""
import numpy as np

A = np.load('Hanger/rio_sdf.npy').astype(np.float32)