# IPython log file

runfile('/home/luyin/Desktop/Anisotropic-MPM/1AA_source/1A_hanger_03_07/1A_generate_path/1A_Hanger_get_target_no_diff/1A_main.py', wdir='/home/luyin/Desktop/Anisotropic-MPM/1AA_source/1A_hanger_03_07/1A_generate_path/1A_Hanger_get_target_no_diff')
runfile('/home/luyin/Desktop/Anisotropic-MPM/1AA_source/1A_hanger_03_07/1A_generate_path/1A_Hanger_get_target_no_diff/1A_main.py', wdir='/home/luyin/Desktop/Anisotropic-MPM/1AA_source/1A_hanger_03_07/1A_generate_path/1A_Hanger_get_target_no_diff')
runfile('/home/luyin/Desktop/Anisotropic-MPM/1AA_source/1A_hanger_03_07/1A_generate_path/1A_Hanger_get_target_no_diff/1A_main.py', wdir='/home/luyin/Desktop/Anisotropic-MPM/1AA_source/1A_hanger_03_07/1A_generate_path/1A_Hanger_get_target_no_diff')
runfile('/home/luyin/Desktop/Anisotropic-MPM/1AA_source/1A_hanger_03_07/1A_generate_path/1A_Hanger_get_target_no_diff/1A_main.py', wdir='/home/luyin/Desktop/Anisotropic-MPM/1AA_source/1A_hanger_03_07/1A_generate_path/1A_Hanger_get_target_no_diff')
