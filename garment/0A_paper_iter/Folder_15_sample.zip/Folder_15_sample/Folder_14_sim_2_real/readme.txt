reporduce: 14, 75, 216
